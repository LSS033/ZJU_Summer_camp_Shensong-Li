/**
 * 存放配置常量(当值不为空时会覆盖env配置)
 */
    let config = {
    //接口父路径
    api: 'http://192.168.0.60:9999/jeecg-boot/', //本地测试
    //单点登录地址
    VUE_APP_CAS_BASE_URL: '',
    //文件预览路径 
    VUE_APP_ONLINE_BASE_URL: ''
} 

export default config;